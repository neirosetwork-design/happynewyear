import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App.tsx";
import "./types/telegram.d.ts";

ReactDOM.createRoot(document.getElementById("root")!).render(<App />);
