export default function ChristmasTree() {
  return (
    <div className="christmas-tree">
      <div className="tree-star">⭐</div>
      <div className="tree-top">
        <div className="tree-layer layer-1" />
        <div className="tree-layer layer-2" />
        <div className="tree-layer layer-3" />
      </div>
      <div className="tree-trunk" />
      <div className="tree-ornaments">
        <span className="ornament" style={{ top: '25%', left: '35%' }}>🔴</span>
        <span className="ornament" style={{ top: '40%', left: '55%' }}>🟡</span>
        <span className="ornament" style={{ top: '55%', left: '30%' }}>🔵</span>
        <span className="ornament" style={{ top: '65%', left: '60%' }}>🔴</span>
        <span className="ornament" style={{ top: '75%', left: '40%' }}>🟡</span>
        <span className="ornament" style={{ top: '35%', left: '50%' }}>🟢</span>
        <span className="ornament" style={{ top: '50%', left: '45%' }}>🔴</span>
      </div>
      <div className="tree-garland">
        ✨✨✨✨✨
      </div>
    </div>
  )
}
