export default function Snowfall() {
  return (
    <div className="snowfall">
      {Array.from({ length: 50 }).map((_, i) => (
        <div
          key={i}
          className="snowflake"
          style={{
            left: `${Math.random() * 100}%`,
            animationDuration: `${3 + Math.random() * 7}s`,
            animationDelay: `${Math.random() * 5}s`,
            fontSize: `${8 + Math.random() * 14}px`,
            opacity: 0.4 + Math.random() * 0.6,
          }}
        >
          ❄
        </div>
      ))}
    </div>
  )
}
