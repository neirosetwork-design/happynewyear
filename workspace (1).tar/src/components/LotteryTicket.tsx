interface LotteryTicketProps {
  ticketNumber: string
  animate: boolean
}

export default function LotteryTicket({ ticketNumber, animate }: LotteryTicketProps) {
  return (
    <div className={`lottery-ticket ${animate ? 'animate-in' : ''}`}>
      <div className="ticket-header">
        <span className="ticket-icon">🎫</span>
        <h2>ЛОТЕРЕЙНЫЙ БИЛЕТ</h2>
        <span className="ticket-icon">🎫</span>
      </div>
      
      <div className="ticket-body">
        <div className="ticket-number-label">Номер билета:</div>
        <div className="ticket-number">
          {ticketNumber.split('').map((digit, i) => (
            <span key={i} className="ticket-digit">{digit}</span>
          ))}
        </div>
        
        <div className="ticket-divider">
          <span>✂️ - - - - - - - - - - - - - - - - - - - - -</span>
        </div>
        
        <div className="ticket-info">
          <div className="ticket-row">
            <span className="ticket-label">Дата розыгрыша:</span>
            <span className="ticket-value">31.12.2027</span>
          </div>
          <div className="ticket-row">
            <span className="ticket-label">Время:</span>
            <span className="ticket-value">00:00 🕛</span>
          </div>
          <div className="ticket-row">
            <span className="ticket-label">Статус:</span>
            <span className="ticket-status active">● Активен</span>
          </div>
        </div>
      </div>
      
      <div className="ticket-footer">
        <p>🎄 С Новым 2027 Годом! 🎄</p>
        <p className="ticket-note">Сохраните этот билет до момента розыгрыша</p>
      </div>

      <div className="ticket-decoration-left">🎁</div>
      <div className="ticket-decoration-right">🎁</div>
    </div>
  )
}
