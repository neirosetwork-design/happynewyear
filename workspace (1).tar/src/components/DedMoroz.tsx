export default function DedMoroz() {
  return (
    <div className="ded-moroz">
      <div className="ded-body">
        <div className="ded-head">
          <div className="ded-hat">
            <div className="ded-hat-tip" />
          </div>
          <div className="ded-face">
            <div className="ded-eyes">
              <span className="ded-eye left">•</span>
              <span className="ded-eye right">•</span>
            </div>
            <div className="ded-nose">🔴</div>
            <div className="ded-beard">
              <div className="beard-layer" />
              <div className="beard-layer" />
              <div className="beard-layer" />
            </div>
            <div className="ded-mustache">
              <span className="mustache-left" />
              <span className="mustache-right" />
            </div>
          </div>
        </div>
        <div className="ded-coat">
          <div className="coat-belt" />
          <div className="coat-trim" />
        </div>
        <div className="ded-staff">
          <div className="staff-crystal">💎</div>
          <div className="staff-pole" />
        </div>
      </div>
      <div className="ded-label">Дед Мороз</div>
    </div>
  )
}
