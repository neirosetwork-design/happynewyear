import { useState, useEffect } from 'react'
import Snowfall from './components/Snowfall'
import ChristmasTree from './components/ChristmasTree'
import DedMoroz from './components/DedMoroz'
import LotteryTicket from './components/LotteryTicket'
import './App.css'

function App() {
  const [showTicket, setShowTicket] = useState(false)
  const [ticketNumber, setTicketNumber] = useState('')
  const [animate, setAnimate] = useState(false)

  useEffect(() => {
    // Telegram WebApp initialization
    if (window.Telegram?.WebApp) {
      window.Telegram.WebApp.ready()
      window.Telegram.WebApp.expand()
    }

    // Generate random ticket number
    const num = Math.floor(100000 + Math.random() * 900000).toString()
    setTicketNumber(num)

    // Show ticket with animation
    setTimeout(() => {
      setAnimate(true)
      setTimeout(() => setShowTicket(true), 500)
    }, 1500)
  }, [])

  return (
    <div className="app-container">
      <Snowfall />
      
      {/* Stars background */}
      <div className="stars">
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={i}
            className="star"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 40}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className="header">
        <h1 className="title">🎄 Новогодняя Лотерея 🎄</h1>
        <p className="subtitle">Волшебство Нового Года 2027!</p>
      </header>

      {/* Ded Moroz and Tree */}
      <div className="scene">
        <DedMoroz />
        <ChristmasTree />
      </div>

      {/* Lottery Ticket */}
      {showTicket && (
        <LotteryTicket ticketNumber={ticketNumber} animate={animate} />
      )}

      {/* Draw info */}
      <div className="draw-info">
        <div className="draw-info-card">
          <div className="draw-icon">🎰</div>
          <h2 className="draw-title">РОЗЫГРЫШ</h2>
          <p className="draw-date">31 декабря 2027</p>
          <p className="draw-time">в полночь 🕛</p>
          <div className="draw-divider"></div>
          <p className="draw-note">
            Сохраните свой билет до момента розыгрыша. 
            Победители будут определены случайным образом.
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="footer">
        <p>🎅 С Наступающим Новым Годом! 🎅</p>
        <p className="footer-small">Удачи в новом году! ✨</p>
      </footer>

      {/* Decorative garland */}
      <div className="garland">
        {Array.from({ length: 15 }).map((_, i) => (
          <div
            key={i}
            className="garland-light"
            style={{
              animationDelay: `${i * 0.2}s`,
              backgroundColor: ['#ff0000', '#00ff00', '#ffff00', '#0088ff', '#ff00ff'][i % 5],
            }}
          />
        ))}
      </div>
    </div>
  )
}

export default App
